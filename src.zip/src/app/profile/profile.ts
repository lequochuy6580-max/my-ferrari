import { Component, OnInit, Inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser, CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Footer } from '../footer/footer';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, RouterLink, ReactiveFormsModule, Footer],
  templateUrl: './profile.html',
  styleUrl: './profile.css',
})
export class Profile implements OnInit {
  username = '';
  fullname = '';
  email = '';
  joinDate = '';

  isEditing = false;
  isSaving = false;
  saveSuccess = false;
  saveError = '';

  editForm = new FormGroup({
    fullname: new FormControl('', [Validators.required, Validators.minLength(3)]),
    email: new FormControl('', [Validators.required, Validators.email]),
  });

  isChangingPassword = false;
  passwordForm = new FormGroup({
    currentPassword: new FormControl('', [Validators.required]),
    newPassword: new FormControl('', [Validators.required, Validators.minLength(6)]),
    confirmPassword: new FormControl('', [Validators.required]),
  });
  passwordError = '';
  passwordSuccess = false;

  constructor(
    private router: Router,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {}

  ngOnInit(): void {
    if (!isPlatformBrowser(this.platformId)) return;

    this.username  = localStorage.getItem('currentUser') ?? '';
    this.fullname  = localStorage.getItem('currentUserFullname') ?? this.username;
    this.email     = localStorage.getItem('currentUserEmail') ?? '';
    this.joinDate  = localStorage.getItem('currentUserJoinDate') ?? this.getTodayDate();

    if (!localStorage.getItem('currentUserJoinDate')) {
      localStorage.setItem('currentUserJoinDate', this.joinDate);
    }

    this.editForm.patchValue({ fullname: this.fullname, email: this.email });
  }

  private getTodayDate(): string {
    return new Date().toLocaleDateString('vi-VN', {
      day: '2-digit', month: '2-digit', year: 'numeric',
    });
  }

  get avatarInitial(): string {
    return (this.fullname || this.username).charAt(0).toUpperCase();
  }

  toggleEdit(): void {
    this.isEditing = !this.isEditing;
    this.saveSuccess = false;
    this.saveError = '';
    if (this.isEditing) {
      this.editForm.patchValue({ fullname: this.fullname, email: this.email });
    }
  }

  saveProfile(): void {
    this.editForm.markAllAsTouched();
    if (this.editForm.invalid) return;

    this.isSaving = true;
    this.saveError = '';
    const { fullname, email } = this.editForm.value;

    setTimeout(() => {
      localStorage.setItem('currentUserFullname', fullname ?? '');
      localStorage.setItem('currentUserEmail', email ?? '');
      this.fullname = fullname ?? '';
      this.email = email ?? '';
      this.isSaving = false;
      this.saveSuccess = true;
      this.isEditing = false;
      setTimeout(() => this.saveSuccess = false, 3000);
    }, 600);
  }

  togglePasswordChange(): void {
    this.isChangingPassword = !this.isChangingPassword;
    this.passwordError = '';
    this.passwordSuccess = false;
    this.passwordForm.reset();
  }

  changePassword(): void {
    this.passwordForm.markAllAsTouched();
    if (this.passwordForm.invalid) return;
    const { newPassword, confirmPassword } = this.passwordForm.value;
    if (newPassword !== confirmPassword) {
      this.passwordError = 'Mật khẩu xác nhận không khớp.';
      return;
    }
    this.isSaving = true;
    setTimeout(() => {
      this.passwordSuccess = true;
      this.passwordError = '';
      this.isSaving = false;
      this.passwordForm.reset();
      setTimeout(() => {
        this.passwordSuccess = false;
        this.isChangingPassword = false;
      }, 2500);
    }, 700);
  }

  logout(): void {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.removeItem('isLoggedIn');
      localStorage.removeItem('currentUser');
      localStorage.removeItem('currentUserFullname');
      localStorage.removeItem('currentUserEmail');
      localStorage.removeItem('currentUserJoinDate');
    }
    this.router.navigate(['/']);
  }

  f(name: string)  { return this.editForm.get(name); }
  pf(name: string) { return this.passwordForm.get(name); }
}