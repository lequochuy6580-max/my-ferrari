import { Component, OnInit, Inject, PLATFORM_ID, ChangeDetectorRef } from '@angular/core'; // ← ADD ChangeDetectorRef
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../services/api.service';
import { CartService } from '../services/cart.service';
import { Footer } from '../footer/footer';

interface Product {
  id: number;
  name: string;
  price: number;
  category: string;
  description: string;
  Images?: any;
  image?: string;
  images?: any;
  video?: string;
}

@Component({
  selector: 'app-viewdetail',
  standalone: true,
  imports: [CommonModule, FormsModule, Footer],
  templateUrl: './viewdetail.html',
  styleUrl: './viewdetail.css',
})
export class Viewdetail implements OnInit {
  product: Product | null = null;
  isLoading: boolean = false;
  errorMessage: string = '';
  quantity: number = 1;

  private fallbackImages = [
    'media/sf90.1.jpg',
    'media/sf90.2.jpg',
    'media/sf90.3.jpg',
    'media/sf90.4.jpg',
    'media/1987-Ferrari-F40-004.jpg',
    'media/2003-Ferrari-Enzo1383682_.webp',
    'media/2020-Ferrari-F8-Tributo-007-1600.jpg',
    'media/dean_smith-enzo_laf-130.jpg',
    'media/ferrari-488-gtb-car-red-cars-wallpaper-preview.jpg',
    'media/red-car-car-luxury-vehicle-red-wallpaper-preview.jpg',
    'media/red-lights-ferrari-ferrari-the-bridge-hd-wallpaper-preview.jpg',
    'media/pexels-alessandro-carrarini-31300621-12576612.jpg',
  ];

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private apiService: ApiService,
    private cartService: CartService,
    private cdr: ChangeDetectorRef,                           // ← ADD
    @Inject(PLATFORM_ID) private platformId: Object
  ) {}

  ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.loadProductDetail();
    }
  }

  private async loadProductDetail() {
    this.isLoading = true;
    try {
      let productId: any = this.route.snapshot.queryParams['id'];

      console.log('📍 URL:', window.location.href);
      console.log('📌 Query params["id"]:', productId);

      if (!productId) {
        productId = this.route.snapshot.paramMap.get('id');
        console.log('📌 Param map id:', productId);
      }

      console.log('🔍 Final productId:', productId);

      if (!productId) {
        this.errorMessage = '❌ Không tìm thấy ID sản phẩm. URL phải có ?id=NUMBER';
        return;
      }

      console.log('⏳ Fetching product with ID:', productId);
      let product = await this.apiService.getProductById(productId);

      // Retry once if not found (in case cache wasn't ready)
      if (!product) {
        console.log('⚠️ Product not found, retrying after 500ms...');
        await new Promise(resolve => setTimeout(resolve, 500));
        product = await this.apiService.getProductById(productId);
      }

      if (!product) {
        this.errorMessage = '❌ Sản phẩm không tồn tại';
      } else {
        console.log('✅ Product loaded:', product);
        this.product = product;
        this.errorMessage = '';
      }
    } catch (error) {
      console.error('Error loading product:', error);
      this.errorMessage = '❌ Lỗi khi tải sản phẩm. Vui lòng thử lại!';
    } finally {
      this.isLoading = false;
      this.cdr.detectChanges();                               // ← ADD
    }
  }

  getImageUrl(): string {
    if (!this.product) return this.getFallbackImage();

    const p = this.product;

    if (typeof p.Images === 'string' && p.Images.length > 0) return p.Images;
    if (Array.isArray(p.Images) && p.Images.length > 0) return p.Images[0];

    if (typeof p.images === 'string' && p.images.length > 0) return p.images;
    if (Array.isArray(p.images) && p.images.length > 0) return p.images[0];

    if (p.image) return p.image;

    return this.getFallbackImage();
  }

  private getFallbackImage(): string {
    if (!this.product) return this.fallbackImages[0];
    const index = (this.product.id % this.fallbackImages.length);
    return this.fallbackImages[index];
  }

  addToCart() {
    if (!this.product) return;

    for (let i = 0; i < this.quantity; i++) {
      this.cartService.addToCart(this.product);
    }

    alert(`✅ Thêm ${this.quantity} sản phẩm vào giỏ hàng thành công!`);
    this.quantity = 1;
  }

  increaseQuantity() {
    this.quantity++;
  }

  decreaseQuantity() {
    if (this.quantity > 1) {
      this.quantity--;
    }
  }

  goBack() {
    this.router.navigate(['/shop']);
  }

  onImageError(event: Event) {
    const img = event.target as HTMLImageElement;
    if (!img.src.includes('media/')) {
      img.src = this.getFallbackImage();
    }
  }
}