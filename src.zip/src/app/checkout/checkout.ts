// ========================================
// Checkout Component - Trang thanh toán
// ========================================
import { Component, OnInit, Inject, PLATFORM_ID } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CartService } from '../services/cart.service';
import { Router } from '@angular/router';
import { Footer } from '../footer/footer';

// Interface định nghĩa cấu trúc form thanh toán
interface CheckoutForm {
  fullName: string;    // Họ và tên khách hàng
  email: string;       // Email liên hệ
  phone: string;       // Số điện thoại
  address: string;     // Địa chỉ giao hàng
  city: string;        // Thành phố
  zipCode: string;     // Mã bưu điện
  paymentMethod: string;  // Phương thức thanh toán
}

// Interface định nghĩa cấu trúc sản phẩm trong giỏ
interface CartItem {
  id: number;          // ID sản phẩm
  name: string;        // Tên sản phẩm
  price: number;       // Giá sản phẩm
  quantity: number;    // Số lượng
  img: string;         // URL ảnh
}

@Component({
  selector: 'app-checkout',
  standalone: true,
  imports: [CommonModule, FormsModule, Footer],  // Dùng FormsModule để ngForm hoạt động
  templateUrl: './checkout.html',
  styleUrl: './checkout.css',
})
// CheckoutComponent - Xử lý đơn hàng: nhập thông tin, validata, tạo order
export class Checkout implements OnInit {
  // Danh sách sản phẩm trong giỏ hàng
  cart: CartItem[] = [];
  // Tổng tiền hàng
  total: number = 0;
  // Tổng số lượng sản phẩm
  totalItems: number = 0;
  // Trạng thái: đang xử lý thanh toán (để disable button)
  isProcessing: boolean = false;
  // Thông báo lỗi (hiển thị nếu validation thất bại)
  errorMessage: string = '';
  // Thông báo thành công (hiển thị khi đặt hàng thành công)
  successMessage: string = '';

  // Object chứa dữ liệu form thanh toán
  checkoutForm: CheckoutForm = {
    fullName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    zipCode: '',
    paymentMethod: 'credit-card'  // Mặc định là thẻ tín dụng
  };

  // Constructor - Tiêm CartService, Router, và kiểm tra môi trường
  constructor(
    private cartService: CartService,
    private router: Router,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {}

  // Angular lifecycle: Chạy sau khi component khởi tạo
  ngOnInit() {
    // Chỉ chạy trên browser (không chạy trên server SSR)
    if (isPlatformBrowser(this.platformId)) {
      this.loadCart();  // Tải sản phẩm từ giỏ hàng
    }
  }

  // Hàm tải giỏ hàng từ CartService
  loadCart() {
    // Lấy danh sách sản phẩm từ CartService
    this.cart = this.cartService.getCart();
    
    // Nếu giỏ trống, hiển thị lỗi
    if (this.cart.length === 0) {
      this.errorMessage = '🛒 Giỏ hàng trống! Vui lòng thêm sản phẩm trước khi thanh toán.';
      return;
    }

    // Tính tổng tiền và số lượng
    this.calculateTotal();
  }

  // Hàm tính tổng tiền và tổng số lượng
  calculateTotal() {
    this.total = 0;       // Reset tổng tiền
    this.totalItems = 0;  // Reset tổng số lượng
    
    // Lặp qua từng sản phẩm để cộng tiền
    this.cart.forEach(item => {
      this.total += item.price * item.quantity;  // Cộng: giá × số lượng
      this.totalItems += item.quantity;          // Cộng số lượng
    });
  }

  // Hàm kiến tra form thanh toán có hợp lệ không
  // Trả về true nếu tất cả dữ liệu hợp lệ, false nếu có lỗi
  validateForm(): boolean {
    // Kiến tra họ tên không để trống
    if (!this.checkoutForm.fullName.trim()) {
      this.errorMessage = '❌ Vui lòng nhập tên đầy đủ';
      return false;
    }

    // Kiến tra email hợp lệ (phải có @)
    if (!this.checkoutForm.email.trim() || !this.isValidEmail(this.checkoutForm.email)) {
      this.errorMessage = '❌ Vui lòng nhập email hợp lệ';
      return false;
    }

    // Kiến tra số điện thoại không để trống
    if (!this.checkoutForm.phone.trim()) {
      this.errorMessage = '❌ Vui lòng nhập số điện thoại';
      return false;
    }

    // Kiến tra địa chỉ không để trống
    if (!this.checkoutForm.address.trim()) {
      this.errorMessage = '❌ Vui lòng nhập địa chỉ';
      return false;
    }

    // Kiến tra thành phố không để trống
    if (!this.checkoutForm.city.trim()) {
      this.errorMessage = '❌ Vui lòng nhập thành phố';
      return false;
    }

    // Kiến tra mã bưu điện không để trống
    if (!this.checkoutForm.zipCode.trim()) {
      this.errorMessage = '❌ Vui lòng nhập mã bưu điện';
      return false;
    }

    return true;  // Nếu hết tất cả kiến tra, return true
  }

  // Hàm kiến tra định dạng email có hợp lệ không
  // Dùng regex để kiến tra: tên@domain.com
  isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;  // Regex email
    return emailRegex.test(email);
  }

  // Hàm xử lý khi nhấn nút "Thanh toán" / "Place Order"
  async handleCheckout(event: Event) {
    event.preventDefault();  // Prevent form reload (tránh reload trang)
    this.errorMessage = '';  // Clear previous errors
    this.successMessage = '';  // Clear previous success messages

    // Kiến tra form hợp lệ
    if (!this.validateForm()) {
      return;  // Nếu không hợp lệ, từ bỏ
    }

    this.isProcessing = true;  // Disable button khi đang xử lý

    try {
      // Giả lập delay khi tạo order (để có cảm giác thực tế)
      await new Promise(resolve => setTimeout(resolve, 1500));

      // Tạo object order với toàn bộ thông tin
      const order = {
        id: Date.now(),  // ID order = timestamp hiện tại
        customerName: this.checkoutForm.fullName,  // Tên khách hàng
        email: this.checkoutForm.email,  // Email
        phone: this.checkoutForm.phone,  // Điện thoại
        address: this.checkoutForm.address,  // Địa chỉ
        city: this.checkoutForm.city,  // Thành phố
        zipCode: this.checkoutForm.zipCode,  // Mã bưu điện
        paymentMethod: this.checkoutForm.paymentMethod,  // Phương thức thanh toán
        items: this.cart,  // Các sản phẩm đặt
        totalAmount: this.total,  // Tổng tiền
        totalItems: this.totalItems,  // Tổng số lượng
        orderDate: new Date().toISOString(),  // Ngày đặt hàng
        status: 'pending'  // Trạng thái: chờ xử lý
      };

      // Lưu order vào localStorage
      // Lấy danh sách order cũ (nếu có)
      const orders = JSON.parse(localStorage.getItem('orders') || '[]');
      // Thêm order mới vào danh sách
      orders.push(order);
      // Lưu lại vào localStorage
      localStorage.setItem('orders', JSON.stringify(orders));

      // Xóa giỏ hàng sau khi đặt hàng thành công
      this.cartService.clearCart();

      // Hiển thị thông báo thành công
      this.successMessage = '✅ Đơn hàng đặt thành công!';
      
      // Sau 2 giây, quay lại trang chủ
      setTimeout(() => {
        this.router.navigate(['/']);
      }, 2000);

    } catch (error) {
      console.error('Checkout error:', error);
      this.errorMessage = '❌ Có lỗi xảy ra. Vui lòng thử lại!';
    } finally {
      this.isProcessing = false;  // Bật lại button sau khi xong
    }
  }

  // Hàm xóa một sản phẩm khỏi giỏ
  // index: vị trí sản phẩm cần xóa
  removeItem(index: number) {
    this.cartService.removeItem(index);  // Xóa từ CartService
    this.loadCart();  // Reload giỏ hàng (tính lại tổng tiền)
  }

  // Hàm thay đổi số lượng sản phẩm
  // index: vị trí sản phẩm, quantity: số lượng mới
  updateQuantity(index: number, quantity: number) {
    // Kiến tra số lượng phải > 0
    if (quantity > 0) {
      this.cartService.updateQuantity(index, quantity);  // Cập nhật trong CartService
      this.loadCart();  // Reload giỏ hàng (tính lại tổng tiền)
    }
  }
  // Kết thúc CheckoutComponent
}
