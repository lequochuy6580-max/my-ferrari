import { Component, OnInit, Inject, PLATFORM_ID } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from '../services/api.service';
import { CartService } from '../services/cart.service';

@Component({
  selector: 'app-detail',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="product-detail-container">
      <div id="detail-content"></div>
    </div>
  `,
  styleUrl: './detail.css'
})
export class Detail implements OnInit {
  constructor(
    private route: ActivatedRoute,
    private apiService: ApiService,
    private cartService: CartService,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {}

  ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      // Đăng ký global functions TRƯỚC khi load (vì innerHTML có onclick)
      this.setupGlobalFunctions();
      this.loadProductDetail();
    }
  }

  private async loadProductDetail() {
    const detailContent = document.getElementById('detail-content');
    if (!detailContent) return;

    // Hiển thị loading
    detailContent.innerHTML = `<p style="color:#fff; text-align:center; padding:40px;">Đang tải sản phẩm...</p>`;

    try {
      let productId: any;

      // Lấy id từ route param trước, fallback sang query string
      const routeParam = this.route.snapshot.paramMap.get('id');
      if (routeParam) {
        productId = routeParam;
      } else {
        const params = new URLSearchParams(window.location.search);
        productId = params.get('id');
      }

      if (!productId) {
        detailContent.innerHTML = '<h3 style="color:#f00; text-align:center;">Không tìm thấy ID sản phẩm.</h3>';
        return;
      }

      const product = await this.apiService.getProductById(productId);

      if (!product) {
        detailContent.innerHTML = '<h3 style="color:#f00; text-align:center;">Sản phẩm không tồn tại.</h3>';
        return;
      }

      // Xử lý ảnh: hỗ trợ mảy hoặc string
      const fallbackImages = [
        'media/sf90.1.jpg',
        'media/sf90.2.jpg',
        'media/sf90.3.jpg',
        'media/sf90.4.jpg',
        'media/1987-Ferrari-F40-004.jpg',
        'media/2003-Ferrari-Enzo1383682_.webp',
        'media/2020-Ferrari-F8-Tributo-007-1600.jpg',
        'media/dean_smith-enzo_laf-130.jpg',
        'media/ferrari-488-gtb-car-red-cars-wallpaper-preview.jpg',
        'media/red-car-car-luxury-vehicle-red-wallpaper-preview.jpg',
        'media/red-lights-ferrari-ferrari-the-bridge-hd-wallpaper-preview.jpg',
        'media/pexels-alessandro-carrarini-31300621-12576612.jpg',
      ];
      
      const getFallback = () => {
        const index = (product.id % fallbackImages.length);
        return fallbackImages[index];
      };
      
      const fallbackForError = getFallback();
      
      const imageUrl =
        (Array.isArray(product.images) ? product.images[0] : null) ||
        (Array.isArray(product.Images) ? product.Images[0] : null) ||
        product.image ||
        product.Images ||
        fallbackForError;

      const videoUrl = product.video || '';

      detailContent.innerHTML = `
        <div class="product-detail fade-in">
          <div class="product-image">
            <img
              src="${imageUrl}"
              alt="${product.name}"
              width="400"
              height="400"
              onerror="this.src='${fallbackForError}'"
              style="width:100%; border-radius:8px;"
            >
            ${videoUrl ? `
              <video src="${videoUrl}" autoplay muted loop style="width:100%; margin-top:20px; border-radius:8px;"></video>
            ` : ''}
          </div>
          <div class="product-info">
            <h1>${product.name}</h1>
            <p class="price">${Number(product.price).toLocaleString('en-US')} USD</p>
            <p class="category">Category: ${product.category || 'Not specified'}</p>
            <p class="description">${product.description || 'No description available'}</p>
            <div class="product-actions">
              <button class="btn" onclick="addToCart(${product.id})">🛒 Add to Cart</button>
              <button class="btn" onclick="window.history.back()">← Back</button>
            </div>
          </div>
        </div>
      `;
    } catch (error) {
      console.error('Error loading product:', error);
      const detailContent = document.getElementById('detail-content');
      if (detailContent) {
        detailContent.innerHTML = `<h3 style="color:#f00; text-align:center;">❌ Lỗi khi tải sản phẩm.</h3>`;
      }
    }
  }

  private setupGlobalFunctions() {
    const win = window as any;

    win.addToCart = (productId: number) => {
      this.apiService.getProductById(productId).then((product: any) => {
        if (product) {
          this.cartService.addToCart(product);
          alert('Product added to cart!');
        }
      });
    };
  }
}