import { Component, OnInit, Inject, PLATFORM_ID, ChangeDetectorRef } from '@angular/core';
import { CommonModule, isPlatformBrowser } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../services/api.service';
import { CartService } from '../services/cart.service';
import { ProductItemComponent } from '../product-item/product-item';
import { Footer } from '../footer/footer';

@Component({
  selector: 'app-shop',
  imports: [CommonModule, FormsModule, ProductItemComponent, Footer],
  templateUrl: './shop.html',
  styleUrl: './shop.css',
})
export class Shop implements OnInit {
  allProducts: any[] = [];
  filteredProducts: any[] = [];

  isLoading = true;
  currentFilter: 'all' | 'classic' | 'modern' | 'sale' | 'grand-tourer' | 'hypercar' = 'all';
  sortOrder: 'default' | 'asc' | 'desc' = 'default';
  searchKeyword = '';

  constructor(
    private apiService: ApiService,
    private cartService: CartService,
    private route: ActivatedRoute,
    private router: Router,
    private cdr: ChangeDetectorRef,
    @Inject(PLATFORM_ID) private platformId: Object
  ) {}

  ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.route.queryParams.subscribe(params => {
        const q = params['q'] || '';
        this.searchKeyword = q;
        this.loadProducts();
      });
    }
  }

  async loadProducts() {
    this.isLoading = true;
    try {
      this.allProducts = await this.apiService.getProducts();
      this.applyFilters();
    } catch (err) {
      console.error('Error loading products:', err);
      this.allProducts = [];
      this.filteredProducts = [];
    } finally {
      this.isLoading = false;
      this.cdr.detectChanges();
    }
  }

  setFilter(filter: 'all' | 'classic' | 'modern' | 'sale' | 'grand-tourer' | 'hypercar') {
    this.currentFilter = filter;
    this.applyFilters();
  }

  setSortOrder(order: 'default' | 'asc' | 'desc') {
    this.sortOrder = order;
    this.applyFilters();
  }

  onSearchInput() {
    this.applyFilters();
    // Sync query param with search keyword
    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: { q: this.searchKeyword || null },
      queryParamsHandling: 'merge',
    });
  }

  clearSearch() {
    this.searchKeyword = '';
    this.onSearchInput();
  }

  private applyFilters() {
    let result = [...this.allProducts];

    // 1. Category filter
    if (this.currentFilter === 'classic') {
      result = result.filter(p => p.category === 'classic');
    } else if (this.currentFilter === 'modern') {
      result = result.filter(p => p.category === 'modern' || !p.category);
    } else if (this.currentFilter === 'grand-tourer') {
      result = result.filter(p => p.category === 'grand-tourer');
    } else if (this.currentFilter === 'hypercar') {
      result = result.filter(p => p.category === 'hypercar');
    } else if (this.currentFilter === 'sale') {
      result = result.filter(p =>
        p.discount > 0 || (p.sale_price && p.sale_price < p.price)
      );
    }

    // 2. Search keyword
    const keyword = this.searchKeyword.trim().toLowerCase();
    if (keyword) {
      result = result.filter(p =>
        (p.name || '').toLowerCase().includes(keyword) ||
        (p.description || '').toLowerCase().includes(keyword)
      );
    }

    // 3. Sort
    if (this.sortOrder === 'asc') {
      result.sort((a, b) => (a.price || 0) - (b.price || 0));
    } else if (this.sortOrder === 'desc') {
      result.sort((a, b) => (b.price || 0) - (a.price || 0));
    }

    this.filteredProducts = result;
  }

  addToCart(product: any) {
    this.cartService.addToCart(product);
    alert('✅ Đã thêm vào giỏ hàng!');
  }

  onViewProduct(productId: number) {
    this.router.navigate(['/viewdetail'], { queryParams: { id: productId } });
  }

  get totalResults(): number {
    return this.filteredProducts.length;
  }
}