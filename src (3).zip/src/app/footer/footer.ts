// ========================================
// Footer Component - Phần chân trang
// ========================================
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslatePipe } from '../pipes/translate.pipe';

@Component({
  selector: 'app-footer',
  imports: [CommonModule, TranslatePipe],
  templateUrl: './footer.html',
  styleUrl: './footer.css',
  standalone: true,
})
// FooterComponent - Hiển thị thông tin công ty, liên kết social, copyright ở cuối trang
// Component này không cần xử lý logic, chỉ hiển thị thông tin tĩnh
export class Footer {}
// Kết thúc FooterComponent
